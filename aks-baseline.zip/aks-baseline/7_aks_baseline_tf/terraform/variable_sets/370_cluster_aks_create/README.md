# Working with Total Regional Cores quota

## Background

In the [AKS Baseline project Issue number 377](https://github.com/mspnp/aks-baseline/issues/377) we see a restriction that you might also run into

```
Message: Operation could not be completed as it results in exceeding approved Total Regional Cores quota.

Location: eastus2,
Current Limit: 10,
Current Usage: 0,
Additional Required: 14,
(Minimum) New Limit Required: 14.
```

## See your current Quota in the Azure Portal

Within the Azure portal, go to [Quotas / Compute](https://portal.azure.com/#view/Microsoft_Azure_Capacity/QuotaMenuBlade/~/myQuotas), and search for Quota Name "Total Regional vCPUs" in your Region.

You may well find that the Current Usage shows "0 of 10", and Adjustable is "Yes".

If you raise this to at least 20, then you should be able to support:

- System Node Pool with 4 x 2-core Virtual Machines
- User Node Pool with 3 x 4-core Virtual Machines
