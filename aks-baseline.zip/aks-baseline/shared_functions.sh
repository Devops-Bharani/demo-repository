#!/usr/bin/env bash

RESOURCE_CREATION_SLEEP_DELAY_SECONDS=8
declare -a LOG_LEVELS
LOG_LEVELS=("error" "info" "verbose" "debug")

# Set up logging
log_init() {
  # Check if the log file is writable
  if [[ $log_to_file = true ]]; then
    LOG_DIRECTORY="${SCRIPT_DIRECTORY}/logs"
    # Create log directory if needed
    mkdir -p "$LOG_DIRECTORY"
    LOG_FILE="${LOG_DIRECTORY}/${SCRIPT_NAME}_$(date +'%Y-%m-%dT%H:%M:%S%z').log"
    if ! touch "$LOG_FILE" 2>/dev/null; then
      echo "Log file is not writable. Disabling file logging."
      log_to_file=false
    fi
  fi
}

log() {

  local log_level="$1"
  local message="$2"

  # if $LOG_LEVEL is not set default it to info
  if [[ -z ${LOG_LEVEL+x} ]]; then
    LOG_LEVEL="info"
  fi

  # Filter log level
  case ${LOG_LEVEL} in
  error)
    if [[ ${log_level} != "error" ]]; then
      return
    fi
    ;;

  info)
    if [[ ${log_level} == "verbose" || ${log_level} == "debug" ]]; then
      return
    fi
    ;;

  verbose)
    if [[ ${log_level} == "debug" ]]; then
      return
    fi
    ;;
  esac

  # Build log message
  local log_msg

  if [[ ${LOG_LEVEL} == "debug" ]]; then
    log_msg="[$(date +'%Y-%m-%dT%H:%M:%S%z')] "
    local source="${BASH_SOURCE[1]}:${BASH_LINENO[1]}"
    log_msg+="${source} "
  fi

  if [[ ${log_level} == "error" ]]; then
    log_msg+="[ERROR] "
  fi

  log_msg+="${message}"

  # Output log message
  if [[ ${log_level} == "error" ]]; then
    echo "${log_msg}" >&2
  else
    echo "${log_msg}"
  fi

  # Log to file
  if [[ ${log_to_file} == "true" ]]; then
    printf '%s\n' "${log_msg}" >>"${LOG_FILE}"
  fi

}

# Validate LOG_LEVEL
check_log_level() {
  log debug "Entered function: ${FUNCNAME[0]}"
  # check that $LOG_LEVEL is set and not empty
  if [[ -z "$LOG_LEVEL" ]]; then
    log error "Log level not set"
    # shellcheck disable=SC2153
    log info "Valid log levels are: ${LOG_LEVELS[*]}"
    echo_usage
    exit 1
  fi

  if ! printf '%s\0' "${LOG_LEVELS[@]}" | grep -Fxqz -- "$LOG_LEVEL"; then
    log error "Invalid log level: $LOG_LEVEL"
    log info "Valid log levels are: ${LOG_LEVELS[*]}"
    echo_usage
    exit 1
  fi
  log verbose "LOG_LEVEL: $LOG_LEVEL"
  log debug "Exited function: ${FUNCNAME[0]}"
}

run_command() {
  if [[ ! -t 0 ]]; then
    cat
  fi

  local makes_changes=false # Default to false

  if [[ "$1" == "--makes-changes" ]]; then
    makes_changes=true
    shift # Remove the flag from the arguments list
  fi

  local cmd=("$@")

  # if $USE_SUDO is not set default it to false
  if [[ -z ${USE_SUDO+x} ]]; then
    USE_SUDO=false
  fi
  # Decide whether to use sudo based on the global USE_SUDO setting
  if $USE_SUDO; then
    cmd=("sudo" "${cmd[@]}")
  fi
  # Convert cmd array to string for logging
  printf -v cmd_str '%q ' "${cmd[@]}"

  # if $DRY_RUN_CHANGES is not set default it to false
  if [[ -z ${DRY_RUN_CHANGES+x} ]]; then
    DRY_RUN_CHANGES=false
  fi

  if [[ $makes_changes == true && $DRY_RUN_CHANGES == true ]]; then
    if [[ -t 1 ]]; then
      log verbose "DRY RUN: Would execute: ${cmd_str}"
    fi
    return 0
  else
    # Check if output is being captured
    if [[ -t 1 ]]; then
      log verbose "Preparing to execute: ${cmd_str}"
    fi

    # if $log_to_file is not set default it to false
    if [[ -z ${log_to_file+x} ]]; then
      log_to_file=false
    fi

    if [[ "${log_to_file}" == "true" ]]; then
      "${cmd[@]}" | tee -a "${LOG_FILE}"
    else
      "${cmd[@]}"
    fi
    return $?
  fi
}

# Check if a single tool exists
tool_exists() {
  log debug "Entered function: ${FUNCNAME[0]}"
  local name=$1

  log debug "Checking if tool ${name} exists"
  if ! type -P "${name}" &>/dev/null; then
    log debug "Exited function: ${FUNCNAME[0]}"
    return 1
  fi

  log debug "Exited function: ${FUNCNAME[0]}"
  return 0
}

resource_group_exists() {
  log debug "Entered function: ${FUNCNAME[0]}"
  local name=$1
  log debug "Resource group ${name}: checking if exists"
  if ! run_command az group show --name "${name}" --only-show-errors; then
    log debug "Resource group ${name}:not found"
    log debug "Exited function: ${FUNCNAME[0]}"
    return 1
  else
    log debug "Resource group ${name}: exists"
    log debug "Exited function: ${FUNCNAME[0]}"
    return 0
  fi
}

resource_group_create() {
  log debug "Entered function: ${FUNCNAME[0]}"
  local name=$1
  local location=$2
  log info "Resource group ${name}: creating in location ${location}"
  if ! run_command --makes-changes az group create --name "${name}" --location "${location}" --only-show-errors; then
    log verbose "Resource group ${name}: unable to create in location ${location}"
    log debug "Exited function: ${FUNCNAME[0]}"
    return 1
  fi
  log debug "Exited function: ${FUNCNAME[0]}"
  return 0
}

resource_group_ensure() {
  log debug "Entered function: ${FUNCNAME[0]}"
  local name=$1
  local location=$2

  if ! resource_group_exists "$name"; then
    log info "Resource group ${name}: creating in location ${location}"
    resource_group_create "$name" "$location"
    if [[ $DRY_RUN_CHANGES != true ]]; then
      log info "Sleeping for ${RESOURCE_CREATION_SLEEP_DELAY_SECONDS} seconds after resource creation"
      sleep "${RESOURCE_CREATION_SLEEP_DELAY_SECONDS}"
    fi
  fi

  log debug "Exited function: ${FUNCNAME[0]}"
  return 0
}

storage_account_exists() {
  log debug "Entered function: ${FUNCNAME[0]}"
  local name=$1
  local resource_group=$2

  log debug "Storage account ${name}: checking if exists in resource group ${resource_group}"

  if ! run_command az storage account show --name "${name}" --resource-group "${resource_group}" --only-show-errors &>/dev/null; then
    log debug "Storage account ${name}: not found in resource group ${resource_group}"
    log debug "Exited function: ${FUNCNAME[0]}"
    return 1
  fi

  log debug "Storage account ${name}: exists in resource group ${resource_group}"
  log debug "Exited function: ${FUNCNAME[0]}"
  return 0
}

storage_account_create() {
  log debug "Entered function: ${FUNCNAME[0]}"
  local name=$1
  local resource_group=$2

  log verbose "Storage account ${name}: call storage_account_exists to check if exists in resource group ${resource_group}"
  if storage_account_exists "$name" "$resource_group"; then
    log info "Storage account ${name}: exists in resource group ${resource_group}"
    log verbose "No need to attempt creation"
    log debug "Exited function: ${FUNCNAME[0]}"
    return 0
  fi

  log info "Storage account ${name}: creating in resource group ${resource_group}"
  if ! run_command --makes-changes az storage account create --name "$name" --resource-group "$resource_group" --sku Standard_LRS --encryption-services blob --only-show-errors &>/dev/null; then
    log error "Storage account ${name}: unable to create in resource group ${resource_group}"
    log debug "Exited function: ${FUNCNAME[0]}"
    return 1
  fi

  log verbose "Storage account ${name}: created in resource group ${resource_group}"
  log debug "Exited function: ${FUNCNAME[0]}"
  return 0
}

storage_account_ensure() {
  log debug "Entered function: ${FUNCNAME[0]}"
  local name=$1
  local resource_group=$2

  if ! storage_account_exists "$name" "$resource_group"; then
    storage_account_create "$name" "$resource_group"
    if [[ $DRY_RUN_CHANGES != true ]]; then
      log info "Sleeping for ${RESOURCE_CREATION_SLEEP_DELAY_SECONDS} seconds after resource creation"
      sleep "${RESOURCE_CREATION_SLEEP_DELAY_SECONDS}"
    fi
  else
    log info "Storage account ${name}: exists in resource group ${resource_group}"
  fi
  log debug "Exited function: ${FUNCNAME[0]}"
  return $?
}

# Add network rule
storage_account_add_network_rule() {
  log debug "Entered function: ${FUNCNAME[0]}"
  local name=$1
  local resource_group=$2
  local ip_address=$3

  if ! storage_account_exists "$name" "$resource_group"; then
    log error "Storage account ${name}: not found in resource group ${resource_group}. Can not add network rule"
    log debug "Exited function: ${FUNCNAME[0]}"
    return 1
  fi

  if [[ $ip_address == */32 ]]; then
    log debug "IP address ${ip_address} is a /32 CIDR. Removing CIDR"
    ip_address=${ip_address%/*}
  fi
  log debug "IP address: ${ip_address}"

  log info "Storage account ${name}: ensuring network rule for IP address"
  if ! run_command --makes-changes az storage account network-rule add --account-name "${name}" --resource-group "${resource_group}" --ip-address "${ip_address}" --only-show-errors &>/dev/null; then
    log error "Storage account ${name}: unable to add network rule for IP address"
    log debug "Exited function: ${FUNCNAME[0]}"
    return 1
  fi
  log debug "Exited function: ${FUNCNAME[0]}"
  return 0
}

# Set default action
storage_account_set_network_default_deny() {
  log debug "Entered function: ${FUNCNAME[0]}"
  local name=$1
  local resource_group=$2

  if ! storage_account_exists "$name" "$resource_group"; then
    log error "Storage account ${name} not found in resource group ${resource_group}. Can not set default network access to deny"
    log debug "Exited function: ${FUNCNAME[0]}"
    return 1
  fi

  log info "Storage account ${name}: ensuring default network access is set to Deny"
  log info "In the Azure Portal, this is the option 'Enabled from selected virtual networks and IP addresses'"
  if ! run_command --makes-changes az storage account update --default-action Deny --name "$name" --resource-group "$resource_group" --only-show-errors &>/dev/null; then
    log error "Storage account ${name}: unable to set default network access to Deny"
    log debug "Exited function: ${FUNCNAME[0]}"
    return 1
  fi
  log debug "Exited function: ${FUNCNAME[0]}"
  return 0
}

# Function to check if storage container exists
storage_container_exists() {
  log debug "Entered function: ${FUNCNAME[0]}"
  local container_name=$1
  local account_name=$2
  if ! run_command az storage container show --name "${container_name}" --account-name "${account_name}" --only-show-errors &>/dev/null; then
    log debug "Storage account ${account_name}: container ${container_name} not found"
    log debug "Exited function: ${FUNCNAME[0]}"
    return 1
  fi

  log debug "Storage account ${account_name}: container ${container_name} exists"
  log debug "Exited function: ${FUNCNAME[0]}"
  return 0
}

# Function to create a storage container with error handling
storage_container_create() {
  log debug "Entered function: ${FUNCNAME[0]}"
  local container_name=$1
  local account_name=$2
  log verbose "Checking if storage container ${container_name} exists in storage account ${account_name}"
  if storage_container_exists "$container_name" "$account_name"; then
    log verbose "Storage account ${account_name}: container ${container_name} exists"
    log debug "Exited function: ${FUNCNAME[0]}"
    return 0
  fi

  log info "Storage account ${account_name}: creating container ${container_name}"
  if ! run_command --makes-changes az storage container create --name "${container_name}" --account-name "${account_name}" --only-show-errors &>/dev/null; then
    log error "Storage account ${account_name}: unable to create container ${container_name}"
    log debug "Exited function: ${FUNCNAME[0]}"
    return 1
  fi
  log debug "Exited function: ${FUNCNAME[0]}"
  return 0
}

storage_container_ensure() {
  log debug "Entered function: ${FUNCNAME[0]}"
  local container_name=$1
  local account_name=$2

  if ! storage_container_exists "${container_name}" "${account_name}"; then
    log debug "Storage account ${account_name}: container ${container_name} not found"
    storage_container_create "${container_name}" "${account_name}"
    if [[ $DRY_RUN_CHANGES != true ]]; then
      log info "Sleeping for ${RESOURCE_CREATION_SLEEP_DELAY_SECONDS} seconds after resource creation"
      sleep "${RESOURCE_CREATION_SLEEP_DELAY_SECONDS}"
    fi
  fi
  log debug "Exited function: ${FUNCNAME[0]}"
  return $?
}

storage_file_share_exists() {
  log debug "Entered function: ${FUNCNAME[0]}"
  local share_name=$1
  local account_name=$2

  if ! run_command az storage share show --name "$share_name" --account-name "$account_name" --only-show-errors &>/dev/null; then
    log debug "Storage account ${account_name}: file share ${share_name} not found"
    log debug "Exited function: ${FUNCNAME[0]}"
    return 1
  fi
  log debug "Exited function: ${FUNCNAME[0]}"
  return $?
}

storage_file_share_create() {
  log debug "Entered function: ${FUNCNAME[0]}"
  local share_name=$1
  local account_name=$2

  if storage_file_share_exists "$share_name" "$account_name"; then
    log debug "Exited function: ${FUNCNAME[0]}"
    return 0
  fi

  log info "Storage file share ${share_name}: creating in storage account ${account_name}"
  if ! run_command --makes-changes az storage share create --name "$share_name" --account-name "$account_name" --only-show-errors &>/dev/null; then
    log error "Storage account ${account_name}: unable to create file share ${share_name}"
    log debug "Exited function: ${FUNCNAME[0]}"
    return 1
  fi
  log debug "Exited function: ${FUNCNAME[0]}"
  return 0
}

storage_file_share_ensure() {
  log debug "Entered function: ${FUNCNAME[0]}"
  local share_name=$1
  local account_name=$2

  if ! storage_file_share_exists "$share_name" "$account_name"; then
    log debug "Storage account ${account_name}: file share ${share_name}: not found"
    storage_file_share_create "$share_name" "$account_name"
    if [[ $DRY_RUN_CHANGES != true ]]; then
      log info "Sleeping for ${RESOURCE_CREATION_SLEEP_DELAY_SECONDS} seconds after resource creation"
      sleep "${RESOURCE_CREATION_SLEEP_DELAY_SECONDS}"
    fi
  fi
  log debug "Exited function: ${FUNCNAME[0]}"
  return $?
}

# Check if Entra ID group exists
entra_id_group_exists() {
  log debug "Entered function: ${FUNCNAME[0]}"
  local name=$1

  log debug "Checking if Entra ID group ${name} exists"
  group_id=$(run_command az ad group list --display-name "${name}" --query "[].id" --output tsv)

  if [[ -z $group_id ]]; then
    log debug "Group ${name} does not exist"
    log debug "Exited function: ${FUNCNAME[0]}"
    return 1
  fi

  log info "ID for group ${name} is $(printf '\n\t')${group_id}"
  log info ""
  log debug "Exit code: $?"
  log debug "Exited function: ${FUNCNAME[0]}"
  return $?
}

# Create Entra ID group
entra_id_group_create() {
  log debug "Entered function: ${FUNCNAME[0]}"
  local name=$1
  local mail_nickname=$2
  local description=$3

  log info "Creating Entra ID group ${name}"
  run_command --makes-changes az ad group create --display-name "${name}" --mail-nickname "${mail_nickname}" --description "${description}" --query objectId --output tsv --only-show-errors
  log debug "Exited function: ${FUNCNAME[0]}"
  return $?
}

# Ensure Entra ID group is created
entra_id_group_ensure() {
  log debug "Entered function: ${FUNCNAME[0]}"
  local name=$1
  local mail_nickname=$2
  local description=$3

  if ! entra_id_group_exists "$name"; then
    entra_id_group_create "$name" "$mail_nickname" "$description"
    if [[ $DRY_RUN_CHANGES != true ]]; then
      log info "Sleeping for ${RESOURCE_CREATION_SLEEP_DELAY_SECONDS} seconds after resource creation"
      sleep "${RESOURCE_CREATION_SLEEP_DELAY_SECONDS}"
    fi
  fi
  log debug "Exited function: ${FUNCNAME[0]}"
  return $?
}

# Get group ID from name
entra_id_group_get_id() {
  log debug "Entered function: ${FUNCNAME[0]}"
  local name=$1

  log verbose "Get group ID for group ${name}"
  run_command az ad group show --group "$name" --query id --output tsv --only-show-errors
  log debug "Exited function: ${FUNCNAME[0]}"
  return $?
}

# Get user ID from UPN
entra_id_user_get_id() {
  log debug "Entered function: ${FUNCNAME[0]}"
  local upn=$1

  log verbose "Get user ID for user ${upn}"
  run_command az ad user show --id "$upn" --query id --output tsv --only-show-errors
  log debug "Exited function: ${FUNCNAME[0]}"
  return $?
}

# Check if Entra ID user exists
entra_id_user_exists() {
  log debug "Entered function: ${FUNCNAME[0]}"
  local upn=$1

  log debug "Checking if Entra ID user ${upn} exists"
  user_id=$(az ad user list --filter "userPrincipalName eq '$upn'" --query "[].id" --output tsv)

  if [[ -z $user_id ]]; then
    log debug "User ${upn} does not exist"
    log debug "Exited function: ${FUNCNAME[0]}"
    return 1
  fi

  log info "ID for user ${upn} is $(printf '\n\t')${user_id}"
  log info ""
  log debug "Exit code: $?"
  log debug "Exited function: ${FUNCNAME[0]}"
  return $?
}

# Create Entra ID user
entra_id_user_create() {
  log debug "Entered function: ${FUNCNAME[0]}"
  local display_name=$1
  local upn=$2
  local password=$3

  log info "Creating Entra ID user ${upn}"
  if ! run_command --makes-changes az ad user create --display-name "${display_name}" --user-principal-name "${upn}" --force-change-password-next-sign-in --password "${password}" --query objectId --output tsv --only-show-errors; then
    log error "Unable to create Entra ID user ${upn}"
    log debug "Exited function: ${FUNCNAME[0]}"
    return 1
  fi
  log debug "Exited function: ${FUNCNAME[0]}"
  return $?
}

# Ensure Entra ID user is created
entra_id_user_ensure() {
  log debug "Entered function: ${FUNCNAME[0]}"
  local display_name=$1
  local upn=$2
  local password=$3

  if ! entra_id_user_exists "$upn"; then
    entra_id_user_create "$display_name" "$upn" "$password"
    if [[ $DRY_RUN_CHANGES != true ]]; then
      log info "Sleeping for ${RESOURCE_CREATION_SLEEP_DELAY_SECONDS} seconds after resource creation"
      sleep "${RESOURCE_CREATION_SLEEP_DELAY_SECONDS}"
    fi
  fi
  log debug "Exited function: ${FUNCNAME[0]}"
  return $?
}

# Check user assignment
entra_id_user_assignment_exists() {
  log debug "Entered function: ${FUNCNAME[0]}"
  local group_name=$1
  local user_upn=$2

  log debug "Check if user ${user_upn} is assigned to group ${group_name}"
  group_upn=$(run_command az ad group member list --group "$group_name" --query "[?userPrincipalName=='$user_upn']" --output tsv)

  if [[ -z $group_upn ]]; then
    log debug "User ${user_upn} is not assigned to group ${group_name}"
    log debug "Exited function: ${FUNCNAME[0]}"
    return 1
  fi

  log info "User ${user_upn} is assigned to group ${group_name}"
  log info ""
  log debug "Exited function: ${FUNCNAME[0]}"
  return $?
}

# Ensure user assignment
entra_id_user_assignment_create() {
  log debug "Entered function: ${FUNCNAME[0]}"
  local group_id=$1
  local user_id=$2

  log verbose "Call entra_id_user_assignment_exists to check if user ${user_id} is assigned to group ${group_id}"
  if ! entra_id_user_assignment_exists "$group_id" "$user_id"; then
    log verbose "Assigning user ${user_id} to group ${group_id}"
    run_command --makes-changes az ad group member add --group "$group_id" --member-id "$user_id" --only-show-errors
  fi
  log debug "Exited function: ${FUNCNAME[0]}"
  return $?
}

# Ensure user is assigned to group
entra_id_user_assignment_ensure() {
  log debug "Entered function: ${FUNCNAME[0]}"
  local group_name=$1
  local user_upn=$2
  local group_id
  local user_id

  # call internal function entra_id_group_get_id to get group ID
  log debug "Call entra_id_group_get_id to get group ID for group ${group_name}"
  group_id=$(entra_id_group_get_id "$group_name")
  log debug "Group ID for group ${group_name} is ${group_id}"

  # call internal function entra_id_user_get_id to get user ID
  log debug "Call entra_id_user_get_id to get user ID for user ${user_upn}"
  user_id=$(entra_id_user_get_id "$user_upn")
  log debug "User ID for user ${user_upn} is ${user_id}"

  if ! entra_id_user_assignment_exists "$group_name" "$user_upn"; then
    entra_id_user_assignment_create "$group_id" "$user_id"
    if [[ $DRY_RUN_CHANGES != true ]]; then
      log info "Sleeping for ${RESOURCE_CREATION_SLEEP_DELAY_SECONDS} seconds after resource creation"
      sleep "${RESOURCE_CREATION_SLEEP_DELAY_SECONDS}"
    fi
  fi
  log debug "Exited function: ${FUNCNAME[0]}"
  return $?
}

# Function to ensure the user is logged in to Azure CLI
az_is_logged_in() {
  log debug "Entered function: ${FUNCNAME[0]}"

  log debug "Checking if Azure CLI is logged in"
  if ! run_command az account show --only-show-errors &>/dev/null; then
    log debug "Exit code: 1"
    log debug "Exited function: ${FUNCNAME[0]}"
    return 1
  fi
  log debug "Exit code: 0"
  log debug "Exited function: ${FUNCNAME[0]}"
  return 0
}

# Function to check if the user has more than one subscription
az_has_multiple_subscriptions() {
  log debug "Entered function: ${FUNCNAME[0]}"
  local subscription_count
  log verbose "Checking if user has more than 1 subscription"
  subscription_count=$(run_command az account list --all --query "length([])" --output tsv --only-show-errors)
  log verbose "User has ${subscription_count} subscription(s)"

  if [[ $subscription_count -gt 1 ]]; then
    log debug "Exited function: ${FUNCNAME[0]}"
    return 0
  else
    log debug "Exited function: ${FUNCNAME[0]}"
    return 1
  fi
}

# Check if provider is registered
az_provider_is_registered() {
  log debug "Entered function: ${FUNCNAME[0]}"
  local namespace=$1

  if run_command az provider show --namespace "$namespace" --query registrationState --output tsv --only-show-errors | grep -q Registered; then
    log debug "Exited function: ${FUNCNAME[0]}"
    return 0
  else
    log debug "Exited function: ${FUNCNAME[0]}"
    return 1
  fi
}

# Register a single provider
az_provider_register() {
  log debug "Entered function: ${FUNCNAME[0]}"
  local namespace=$1

  if ! az_provider_is_registered "$namespace"; then
    if ! run_command --makes-changes az provider register --namespace "$namespace" --only-show-errors; then
      log error "Unable to register provider $namespace"
      log debug "Exited function: ${FUNCNAME[0]}"
      return 1
    fi
  fi

  log debug "Exited function: ${FUNCNAME[0]}"
  return 0
}

# Register multiple providers
az_providers_ensure() {
  log debug "Entered function: ${FUNCNAME[0]}"
  local namespaces=("$@")

  for namespace in "${namespaces[@]}"; do
    az_provider_register "$namespace"
  done

  log debug "Exited function: ${FUNCNAME[0]}"
  return $?
}

# Check if feature is registered
az_feature_is_registered() {
  log debug "Entered function: ${FUNCNAME[0]}"
  local name=$1
  local namespace
  local feature
  namespace=$(cut -d'/' -f1 <<<"$name")
  feature=$(cut -d'/' -f2 <<<"$name")

  if run_command az feature list --namespace "$namespace" --name "$feature" --query "[].{state:properties.state}" --output tsv --only-show-errors | grep -q Registered; then
    log debug "Exited function: ${FUNCNAME[0]}"
    return 0
  else
    log debug "Exited function: ${FUNCNAME[0]}"
    return 1
  fi
}

# Register feature
az_feature_register() {
  log debug "Entered function: ${FUNCNAME[0]}"
  local name=$1
  local namespace
  local feature
  namespace=$(cut -d'/' -f1 <<<"$name")
  feature=$(cut -d'/' -f2 <<<"$name")

  run_command --makes-changes az feature register --namespace "$namespace" --name "$feature" --only-show-errors
  log debug "Exited function: ${FUNCNAME[0]}"
}

# Usage
# az_feature_is_registered "microsoft.containerservice/foo"
# az_feature_register "microsoft.containerservice/foo"

# Function to check if an AKS cluster exists
aks_cluster_exists() {
  log debug "Entered function: ${FUNCNAME[0]}"
  local name=$1
  local resource_group=$2
  if ! run_command az aks show --name "${name}" --resource-group "${resource_group}" --only-show-errors &>/dev/null; then
    log debug "AKS cluster ${name} not found in resource group ${resource_group}"
    log debug "Exited function: ${FUNCNAME[0]}"
    return 1
  else
    log debug "AKS cluster ${name} exists in resource group ${resource_group}"
    log debug "Exited function: ${FUNCNAME[0]}"
    return 0
  fi
}
