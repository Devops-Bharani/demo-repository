# Azure Storage for Terraform remote state

## Cost

Free resources created:

- Resource Group
- Storage Account
- Storage Container
- Storage network firewall rule

Chargeable resources created:

- None

However, when a Blob is created, the blob storage used for storing Terraform state does cost a small amount of money (under USD0.50 per month). Details are at [blob pricing](https://azure.microsoft.com/en-gb/pricing/details/storage/blobs/)

## Reference

Adapted from the documentation [Quickstart: Deploy an Azure Kubernetes Service (AKS) cluster using Azure CLI](https://learn.microsoft.com/en-us/azure/aks/learn/quick-kubernetes-deploy-cli)

```bash
az group create \
  --name myResourceGroup \
  --location eastus

az aks create \
  -g myResourceGroup \
  -n myAKSCluster \
  --enable-managed-identity \
  --node-count 1 \
  --enable-addons monitoring \
  --enable-msi-auth-for-monitoring \
  --generate-ssh-keys
```
