# Resource Group created with Terraform

## Cost

Free resources created:

- Resource Group

## Reference

[Quickstart: Create an Azure resource group using Terraform](https://learn.microsoft.com/en-us/azure/developer/terraform/create-resource-group?tabs=azure-cli)

## Files created

- [providers.tf](providers.tf)
- [main.tf](main.tf)
- [variables.tf](variables.tf)
- [outputs.tf](outputs.tf)

## Terraform lifecycle

### Initialise Terraform

```shell
terraform init -upgrade
```

### Create a Terraform execution plan

```shell
terraform plan -out main.tfplan
```

### Apply a Terraform execution plan

```shell
terraform apply main.tfplan
```

### Clean up resources

```shell
terraform plan -destroy -out main.destroy.tfplan
```

Then

```shell
terraform apply main.destroy.tfplan
```
