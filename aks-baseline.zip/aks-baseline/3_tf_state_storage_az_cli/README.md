# Azure Storage for Terraform remote state

## Cost

Free resources created:

- Resource Group
- Storage Account
- Storage Container
- Storage network firewall rule

Chargeable resources created:

- None

However, when a Blob is created, the blob storage used for storing Terraform state does cost a small amount of money (under USD0.50 per month). Details are at [blob pricing](https://azure.microsoft.com/en-gb/pricing/details/storage/blobs/)

## Reference

Adapted from the [store state in Azure storage](https://learn.microsoft.com/en-us/azure/developer/terraform/store-state-in-azure-storage?tabs=azure-cli#2-configure-remote-state-storage-account) example

## Naming

[Resource Group Name](https://learn.microsoft.com/en-us/azure/cloud-adoption-framework/ready/azure-best-practices/resource-naming#example-names-general)

```
rg-<app or service name>-<subscription purpose>-<###>
```

```
rg-tfstate-aksbaseline-001
```

[Storage Account name](https://learn.microsoft.com/en-us/azure/cloud-adoption-framework/ready/azure-best-practices/resource-naming#example-names-storage)

```
st<project, app or service><###>
```

```
sttfstate<YOURINITIALS><yyyymmdd>
```
