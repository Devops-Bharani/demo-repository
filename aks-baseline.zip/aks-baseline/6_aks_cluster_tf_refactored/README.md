# Use Terraform standards

## Cost

Free resources created:

- Resource Group
- Virtual Network
- Subnet

Chargeable resources created:

- AKS cluster
- Log Analytics workspace

## Reference

Adapted from [with_acr](https://github.com/Azure/terraform-azurerm-aks/tree/main/examples/with_acr) example, removing the Premium Azure Container Registry to keep costs and deployment time reasonable.

## Using a standard for Terraform configuration

There are many ways to structure a Terraform project, but Google's [best practices for Terraform](https://cloud.google.com/docs/terraform/best-practices-for-terraform) has

- `backend.tf`
- `data.tf`
- `main.tf`
- `outputs.tf`
- `provider.tf`
- `terraform.tfvars`
- `variables.tf`
- `versions.tf`

> The wonderful thing about standards is that there are so many of them to choose from

Microsoft's [terraform-structure-guidelines](https://microsoft.github.io/code-with-engineering-playbook/continuous-delivery/recipes/terraform/terraform-structure-guidelines/), has good definitions, even though it doesn't have the `versions.tf`

- `backend.tf`: backend configuration file
- `data.tf`: defines information read from different data sources
- `main.tf`: defines the infrastructure objects needed for your configuration (e.g. resource group, role assignment, container registry)
- `outputs.tf`: defines structured data that is exported
- `provider.tf`: defines the list of providers according to the plugins used
- `variables.tf`: defines static, reusable values

## Timings

8 minutes to deploy resources in East US region.

## Terraform

- Split out the backend to its own backend.tf file
- Renamed providers.tf to provider.tf
- Moved variable values to terraform.tfvars, rather than inline within main.tf
- Used var.location throughout
- Removed ability to toggle creation of resource group for AKS cluster
- Renamed variables
- Alphabetised variables
- Updated deprecated syntax to use `private_endpoint_network_policies_enabled` in subnet

```bash
terraform init
terraform plan
terraform apply
```

## Get information on deployed cluster

This is deployed as a public cluster, so we can run from any network segment where we are logged in to Azure CLI

```bash
export AKS_CLUSTER_NAME=prefix-e110aaa2e2bc8ff2-aks
export AKS_RESOURCE_GROUP=e110aaa2e2bc8ff2-rg
az aks show \
  --name "${AKS_CLUSTER_NAME}" \
  --resource-group "${AKS_RESOURCE_GROUP}" \
  --query "{\
    Name:name,\
    KubernetesVersion:kubernetesVersion,\
    NodeCount:agentPoolProfiles[0].count,\
    NodeSize:agentPoolProfiles[0].vmSize,\
    NodeResourceGroup:nodeResourceGroup,\
    PowerState:powerState.code,\
    PrivateFqdn:privateFqdn,\
    ProvisioningState:provisioningState,\
    ResourceGroup:resourceGroup,\
    Location:location,\
    DnsPrefix:dnsPrefix,\
    NetworkPlugin:networkProfile.networkPlugin,\
    NetworkPolicy:networkProfile.networkPolicy,\
    OutboundType:networkProfile.outboundType\
  }" \
  --output jsonc
```

Gives output

```
{
  "DnsPrefix": "prefix-e110aaa2e2bc8ff2",
  "KubernetesVersion": "1.27",
  "Location": "eastus2",
  "Name": "prefix-e110aaa2e2bc8ff2-aks",
  "NetworkPlugin": "azure",
  "NetworkPolicy": "azure",
  "NodeCount": 2,
  "NodeResourceGroup": "MC_e110aaa2e2bc8ff2-rg_prefix-e110aaa2e2bc8ff2-aks_eastus2",
  "NodeSize": "Standard_D2s_v3",
  "OutboundType": "loadBalancer",
  "PowerState": "Running",
  "PrivateFqdn": null,
  "ProvisioningState": "Succeeded",
  "ResourceGroup": "e110aaa2e2bc8ff2-rg"
}
```

## Resources created

Determine with

```bash
export AKS_CLUSTER_NAME=prefix-e110aaa2e2bc8ff2-aks
export AKS_RESOURCE_GROUP=e110aaa2e2bc8ff2-rg
export AKS_REGION=eastus2
./azure-resources-report.sh -g "${AKS_RESOURCE_GROUP}"
"MC_${AKS_RESOURCE_GROUP}_${AKS_CLUSTER_NAME}_${AKS_REGION}" -c
```

```
Resource Group                                             Resource Type                                     Location  Resource Name
e110aaa2e2bc8ff2-rg                                        Microsoft.Resources/resourceGroups                eastus2    e110aaa2e2bc8ff2-rg
e110aaa2e2bc8ff2-rg                                        Microsoft.ContainerService/managedClusters        eastus2    prefix-e110aaa2e2bc8ff2-aks
e110aaa2e2bc8ff2-rg                                        Microsoft.Network/virtualNetworks                 eastus2    e110aaa2e2bc8ff2-vn
e110aaa2e2bc8ff2-rg                                        Microsoft.OperationalInsights/workspaces          eastus2    prefix-e110aaa2e2bc8ff2-workspace
e110aaa2e2bc8ff2-rg                                        Microsoft.OperationsManagement/solutions          eastus2    ContainerInsights(prefix-e110aaa2e2bc8ff2-workspace)
MC_e110aaa2e2bc8ff2-rg_prefix-e110aaa2e2bc8ff2-aks_eastus2  Microsoft.Resources/resourceGroups                eastus2    MC_e110aaa2e2bc8ff2-rg_prefix-e110aaa2e2bc8ff2-aks_eastus2
MC_e110aaa2e2bc8ff2-rg_prefix-e110aaa2e2bc8ff2-aks_eastus2  Microsoft.Compute/virtualMachineScaleSets         eastus2    aks-nodepool-93079230-vmss
MC_e110aaa2e2bc8ff2-rg_prefix-e110aaa2e2bc8ff2-aks_eastus2  Microsoft.ManagedIdentity/userAssignedIdentities  eastus2    omsagent-prefix-e110aaa2e2bc8ff2-aks
MC_e110aaa2e2bc8ff2-rg_prefix-e110aaa2e2bc8ff2-aks_eastus2  Microsoft.ManagedIdentity/userAssignedIdentities  eastus2    prefix-e110aaa2e2bc8ff2-aks-agentpool
MC_e110aaa2e2bc8ff2-rg_prefix-e110aaa2e2bc8ff2-aks_eastus2  Microsoft.Network/loadBalancers                   eastus2    kubernetes
MC_e110aaa2e2bc8ff2-rg_prefix-e110aaa2e2bc8ff2-aks_eastus2  Microsoft.Network/networkSecurityGroups           eastus2    aks-agentpool-25836720-nsg
MC_e110aaa2e2bc8ff2-rg_prefix-e110aaa2e2bc8ff2-aks_eastus2  Microsoft.Network/publicIPAddresses               eastus2    6e4eb53a-355e-4354-8cff-b884a3c0fde9
```

## Remove resources via Terraform

```bash
terraform destroy
```

## Remove resources via Azure CLI

```bash
export AKS_RESOURCE_GROUP=e110aaa2e2bc8ff2-rg
az group delete --name "${AKS_RESOURCE_GROUP}"
```
