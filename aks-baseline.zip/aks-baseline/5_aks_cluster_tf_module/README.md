# Public AKS cluster created with Terraform

## Cost

This code creates Azure resources which cost money.
Ensure that you remove the resources, for instance by running:

```bash
terraform destroy
```

## Reference

Adapted from [with_acr](https://github.com/Azure/terraform-azurerm-aks/tree/main/examples/with_acr) example, removing the Premium Azure Container Registry to keep costs and deployment time reasonable.

### Why use Azure's AKS module

As of this writing (November 2023), AAD Pod Identity is [deprecated](https://azure.github.io/aad-pod-identity/docs/#-announcement):

> We will provide CVE patches until September 2023, at which time the project will be archived. There will be no new releases after September 2023.

It is replaced by [AAD Workload Identity](https://azure.github.io/azure-workload-identity/docs/installation.html) which does require:

- Azure CLI (≥2.32.0)
  - with aks-preview CLI extension installed (≥0.5.50)

Azure's module [terraform-azurerm-aks](https://github.com/Azure/terraform-azurerm-aks) has a boolean input [workload_identity_enabled](https://github.com/Azure/terraform-azurerm-aks#input_workload_identity_enabled)

## Timings

8 minutes to deploy resources in East US region.

## Terraform

Modified [./providers.tf](providers.tf) to have backend:

```hcl
terraform {
  required_version = ">=1.3"
  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = ">= 3.51, < 4.0"
    }
    random = {
      source  = "hashicorp/random"
      version = "3.3.2"
    }
  }
  backend "azurerm" {
    resource_group_name  = "rg-tfstate-aksbaseline-001"
    storage_account_name = "sttfstate<YOURINITIALS><yyyymmdd>"
    container_name       = "tfstate"
    key                  = "terraform.tfstate"
  }
}
```

```bash
terraform init
terraform plan
terraform apply
```

## Get information on deployed cluster

This is deployed as a public cluster, so we can run from any network segment where we are logged in to Azure CLI

```bash
export AKS_CLUSTER_NAME=prefix-e110aaa2e2bc8ff2-aks
export AKS_RESOURCE_GROUP=e110aaa2e2bc8ff2-rg
az aks show \
  --name "${AKS_CLUSTER_NAME}" \
  --resource-group "${AKS_RESOURCE_GROUP}" \
  --query "{\
    Name:name,\
    KubernetesVersion:kubernetesVersion,\
    NodeCount:agentPoolProfiles[0].count,\
    NodeSize:agentPoolProfiles[0].vmSize,\
    NodeResourceGroup:nodeResourceGroup,\
    PowerState:powerState.code,\
    PrivateFqdn:privateFqdn,\
    ProvisioningState:provisioningState,\
    ResourceGroup:resourceGroup,\
    Location:location,\
    DnsPrefix:dnsPrefix,\
    NetworkPlugin:networkProfile.networkPlugin,\
    NetworkPolicy:networkProfile.networkPolicy,\
    OutboundType:networkProfile.outboundType\
  }" \
  --output jsonc
```

Gives output

```
{
  "DnsPrefix": "prefix-e110aaa2e2bc8ff2",
  "KubernetesVersion": "1.27",
  "Location": "eastus2",
  "Name": "prefix-e110aaa2e2bc8ff2-aks",
  "NetworkPlugin": "azure",
  "NetworkPolicy": "azure",
  "NodeCount": 2,
  "NodeResourceGroup": "MC_e110aaa2e2bc8ff2-rg_prefix-e110aaa2e2bc8ff2-aks_eastus2",
  "NodeSize": "Standard_D2s_v3",
  "OutboundType": "loadBalancer",
  "PowerState": "Running",
  "PrivateFqdn": null,
  "ProvisioningState": "Succeeded",
  "ResourceGroup": "e110aaa2e2bc8ff2-rg"
}
```

## Resources created

Determine with

```bash
export AKS_CLUSTER_NAME=prefix-e110aaa2e2bc8ff2-aks
export AKS_RESOURCE_GROUP=e110aaa2e2bc8ff2-rg
export AKS_REGION=eastus2
./azure-resources-report.sh -g "${AKS_RESOURCE_GROUP}"
"MC_${AKS_RESOURCE_GROUP}_${AKS_CLUSTER_NAME}_${AKS_REGION}" -c
```

```
Resource Group                                             Resource Type                                     Location  Resource Name
e110aaa2e2bc8ff2-rg                                        Microsoft.Resources/resourceGroups                eastus2    e110aaa2e2bc8ff2-rg
e110aaa2e2bc8ff2-rg                                        Microsoft.ContainerService/managedClusters        eastus2    prefix-e110aaa2e2bc8ff2-aks
e110aaa2e2bc8ff2-rg                                        Microsoft.Network/virtualNetworks                 eastus2    e110aaa2e2bc8ff2-vn
e110aaa2e2bc8ff2-rg                                        Microsoft.OperationalInsights/workspaces          eastus2    prefix-e110aaa2e2bc8ff2-workspace
e110aaa2e2bc8ff2-rg                                        Microsoft.OperationsManagement/solutions          eastus2    ContainerInsights(prefix-e110aaa2e2bc8ff2-workspace)
MC_e110aaa2e2bc8ff2-rg_prefix-e110aaa2e2bc8ff2-aks_eastus2  Microsoft.Resources/resourceGroups                eastus2    MC_e110aaa2e2bc8ff2-rg_prefix-e110aaa2e2bc8ff2-aks_eastus2
MC_e110aaa2e2bc8ff2-rg_prefix-e110aaa2e2bc8ff2-aks_eastus2  Microsoft.Compute/virtualMachineScaleSets         eastus2    aks-nodepool-93079230-vmss
MC_e110aaa2e2bc8ff2-rg_prefix-e110aaa2e2bc8ff2-aks_eastus2  Microsoft.ManagedIdentity/userAssignedIdentities  eastus2    omsagent-prefix-e110aaa2e2bc8ff2-aks
MC_e110aaa2e2bc8ff2-rg_prefix-e110aaa2e2bc8ff2-aks_eastus2  Microsoft.ManagedIdentity/userAssignedIdentities  eastus2    prefix-e110aaa2e2bc8ff2-aks-agentpool
MC_e110aaa2e2bc8ff2-rg_prefix-e110aaa2e2bc8ff2-aks_eastus2  Microsoft.Network/loadBalancers                   eastus2    kubernetes
MC_e110aaa2e2bc8ff2-rg_prefix-e110aaa2e2bc8ff2-aks_eastus2  Microsoft.Network/networkSecurityGroups           eastus2    aks-agentpool-25836720-nsg
MC_e110aaa2e2bc8ff2-rg_prefix-e110aaa2e2bc8ff2-aks_eastus2  Microsoft.Network/publicIPAddresses               eastus2    6e4eb53a-355e-4354-8cff-b884a3c0fde9
```

## Remove resources via Terraform

```bash
terraform destroy
```

## Remove resources via Azure CLI

```bash
export AKS_RESOURCE_GROUP=e110aaa2e2bc8ff2-rg
az group delete --name "${AKS_RESOURCE_GROUP}"
```
