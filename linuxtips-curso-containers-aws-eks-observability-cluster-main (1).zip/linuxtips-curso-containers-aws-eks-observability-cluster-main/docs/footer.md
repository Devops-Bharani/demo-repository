# Outros Repositórios do Projeto

| Repositório                       | Link                                                                                                                  |
|-----------------------------------|-----------------------------------------------------------------------------------------------------------------------|
| VPC / Networking                  | [Github](https://github.com/msfidelis/linuxtips-curso-containers-aws-eks-networking)                                  |
| Ingress Application Load Balancer | [Github](https://github.com/msfidelis/linuxtips-curso-containers-aws-eks-multicluster-management/tree/main/ingress)   |
| EKS Cluster 01 e 02               | [Github](https://github.com/msfidelis/linuxtips-curso-containers-aws-eks-multicluster-management/tree/main/clusters)  |
| EKS Control Plane do ArgoCD       | [Github](https://github.com/msfidelis/linuxtips-curso-containers-aws-eks-multicluster-management/tree/main/clusters)  |
| EKS Observability Cluster Tools   | [Github](https://github.com/msfidelis/linuxtips-curso-containers-aws-eks-observability-cluster)                       |